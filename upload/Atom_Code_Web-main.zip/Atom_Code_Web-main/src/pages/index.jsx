import Link from "next/link";
import { Tab } from '@headlessui/react'
import { Smartphone, PieChart, Shield, Zap, Clock, MessageSquare, Award, BarChart, BarChart2, Hexagon, Cloud, Code } from 'react-feather';
export default function Home() {
  return (
    <>
      <section className="bg-half-170  d-table w-100" id="home">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-7 col-md-7">
              <div className="title-heading mt-4">
                <h1 className="heading mb-3">Welcome to <span className="text-indigo">Atom Code & MS InfoTech , Genius Academy</span></h1>
                <p className="para-desc text-muted">
                  Join the next generation of AI-powered engineers.
                  Grow your skills and connect with a thriving community.
                  Reimagine engineering with AI-powered tools.
                  Fueled by AI, powered by Atom Code Dev.
                </p>
                <div className="mt-4">
                  <Link href="#getstarted" className="btn btn-primary mt-2 mr-2">Get Started <i className="mdi mdi-chevron-right" /></Link>
                </div>
              </div>
            </div>
            <div className="col-lg-5 col-md-5 mt-4 pt-2 mt-sm-0 pt-sm-0">
              <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/illustratorx/Startup_SVG_css.svg" alt="hive" />
            </div>
          </div>
        </div>
      </section>

      <section className="section" id="getstarted">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 text-center">
              <div className="section-title mb-4 pb-2">
                <h4 className="title mb-4">Our Highlights</h4>
                <p className="text-muted para-desc mb-0 mx-auto">We provide highly scalable &amp; more efficient technical services to enhance<span className="text-indigo font-weight-bold"> Student's</span> skills </p>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-3 col-md-4 mt-4 pt-2">
              <div className="card features fea-primary rounded p-4 bg-light text-center position-relative overflow-hidden border-0">
                <span className="h1 icon2 text-indigo">
                  <PieChart size={40} />
                </span>
                <div className="card-body p-0 content">
                  <h5>Top Programming Languages</h5>
                </div>
                <span className="big-icon text-center">
                  <PieChart size={130} />
                </span>
              </div>
            </div>
            <div className="col-lg-3 col-md-4 mt-4 pt-2">
              <div className="card features fea-primary rounded p-4 bg-light text-center position-relative overflow-hidden border-0">
                <span className="h1 icon2 text-indigo">
                  <Shield size={40} />
                </span>
                <div className="card-body p-0 content">
                  <h5>Most Secured Workspace</h5>
                </div>
                <span className="big-icon text-center">
                  <Shield size={130} />
                </span>
              </div>
            </div>
            <div className="col-lg-3 col-md-4 mt-4 pt-2">
              <div className="card features fea-primary rounded p-4 bg-light text-center position-relative overflow-hidden border-0">
                <span className="h1 icon2 text-indigo">
                  <Zap size={40} />
                </span>
                <div className="card-body p-0 content">
                  <h5>AI based Practices & Security</h5>
                </div>
                <span className="big-icon text-center">
                  <Zap size={130} />
                </span>
              </div>
            </div>
            <div className="col-lg-3 col-md-4 mt-4 pt-2">
              <div className="card features fea-primary rounded p-4 bg-light text-center position-relative overflow-hidden border-0">
                <span className="h1 icon2 text-indigo">
                  <BarChart2 size={40} />
                </span>
                <div className="card-body p-0 content">
                  <h5>Extensive Analysis & Leaderboards</h5>
                </div>
                <span className="big-icon text-center">
                  <BarChart2 size={130} />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="container mt-100 mt-60">
          <div className="row justify-content-center">
            <div className="col-12">
              <div className="section-title text-center mb-4 pb-2">
                <h4 className="title mb-4">Our Platform Features</h4>
                <p className="text-muted para-desc mb-0 mx-auto">Quick view of <span className="text-indigo font-weight-bold">Atom Code</span>'s technicial services.</p>
              </div>
            </div>
          </div>
          <Tab.Group>
            <div className="row align-items-center">
              <div className="col-md-5 mt-4 pt-2">
                <Tab.List className="nav nav-pills bg-white nav-justified flex-column mb-0">
                  <Tab className="nav-item bg-light rounded-md tab-componentx">
                    <div className="nav-link rounded-md">
                      <div className="p-3 text-left">
                        <h5 className="title text-indigo">Code Smarter, Not Harder</h5>
                        <p className="text-muted tab-para mb-0">Explore new coding techniques and patterns with AI-powered suggestions that broaden your knowledge and enhance your coding creativity</p>
                      </div>
                    </div>
                  </Tab>
                  <Tab className="nav-item bg-light rounded-md tab-componentx">
                    <div className="nav-link rounded-md">
                      <div className="p-3 text-left">
                        <h5 className="title text-indigo">Data-Powered Progress Tracking</h5>
                        <p className="text-muted tab-para mb-0">Track learner progress, identify strengths and weaknesses, and visualize the path to mastery with our comprehensive result matrix</p>
                      </div>
                    </div>
                  </Tab>
                  <Tab className="nav-item bg-light rounded-md tab-componentx">
                    <div className="nav-link rounded-md">
                      <div className="p-3 text-left">
                        <h5 className="title text-indigo">Open IDE - Unleash Your Coding Potential</h5>
                        <p className="text-muted tab-para mb-0">The OpenIDE provides an interactive environment where you can learn by doing, with customizable inputs to test your code and refine your problem-solving abilities</p>
                      </div>
                    </div>
                  </Tab>
                  <Tab className="nav-item bg-light rounded-md tab-componentx">
                    <div className="nav-link rounded-md">
                      <div className="p-3 text-left">
                        <h5 className="title text-indigo">Future-Proof Your Skills</h5>
                        <p className="text-muted tab-para mb-0">Unlock lucrative career opportunities with our comprehensive training in MERN/MEAN Full stacks, AWS cloud,  Selenium test automation, Power BI, Devops</p>
                      </div>
                    </div>
                  </Tab>
                </Tab.List>
              </div>
              <div className="col-md-7 col-12 mt-4 pt-2">
                <Tab.Panels className="tab-content ml-lg-4">
                  <Tab.Panel>
                    <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/illustratorx/webx.svg" className="img-fluid mx-auto rounded-md shadow-lg d-block" alt="hive" />
                  </Tab.Panel>
                  <Tab.Panel>
                    <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/illustratorx/Mobile.svg" className="img-fluid mx-auto rounded-md shadow-lg d-block" alt="hive" />
                  </Tab.Panel>
                  <Tab.Panel>
                    <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/illustratorx/t3png.png" className="img-fluid mx-auto rounded-md shadow-lg d-block" alt="hive" />
                  </Tab.Panel>
                  <Tab.Panel>
                    <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/illustratorx/t4png.png" className="img-fluid mx-auto rounded-md shadow-lg d-block" alt="hive" />
                  </Tab.Panel>
                </Tab.Panels>
              </div>
            </div>
          </Tab.Group>
        </div>
      </section>
      {/* Start */}
      <section className="section pt-0">
        <div className="container">
          <div className="row mt-4 pt-2 position-relative" id="counter" style={{ zIndex: 1 }}>
            <div className="col-md-3 col-6 mt-4 pt-2">
              <div className="counter-box text-center">
                <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/HomeAsstes/Asset190.svg" className="avatar avatar-small" alt="hive" />
                <h2 className="mb-0 mt-4"><span className="counter-value" data-count={30}>30</span>+</h2>
                <h6 className="counter-head text-muted">Happy Client</h6>
              </div>
            </div>
            <div className="col-md-3 col-6 mt-4 pt-2">
              <div className="counter-box text-center">
                <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/HomeAsstes/Asset189.svg" className="avatar avatar-small" alt="hive" />
                <h2 className="mb-0 mt-4"><span className="counter-value" data-count={100}>100</span>%</h2>
                <h6 className="counter-head text-muted">Client Retention Rate</h6>
              </div>
            </div>
            <div className="col-md-3 col-6 mt-4 pt-2">
              <div className="counter-box text-center">
                <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/HomeAsstes/Asset192.svg" className="avatar avatar-small" alt="hive" />
                <h2 className="mb-0 mt-4"><span className="counter-value" data-count={5}>6k</span>+</h2>
                <h6 className="counter-head text-muted">Students Trained</h6>
              </div>
            </div>
            <div className="col-md-3 col-6 mt-4 pt-2">
              <div className="counter-box text-center">
                <img src="https://ik.imagekit.io/atominc/ATOMCODE_Web/HomeAsstes/Asset187.svg" className="avatar avatar-small" alt="hive" />
                <h2 className="mb-0 mt-4"><span className="counter-value" data-count={50}>50</span>+</h2>
                <h6 className="counter-head text-muted">Team size</h6>
              </div>
            </div>
          </div>
          <div className="feature-posts-placeholder bg-light" />
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12">
              <div className="section-title text-center mb-4 pb-2">
                <h4 className="title mb-4">Universities / Institution Partnership &amp; Collaboration</h4>
                <p className="text-muted para-desc mx-auto mb-0">We collaborate with various universities and top tier institutions to provide platform, cutting-edge training and certification programs.</p>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-4 mt-4 pt-2">
              <div className="card features work-process bg-transparent process-arrow border-0 text-center">
                <div className="icons rounded h1 text-center text-indigo px-3">
                  <Hexagon size={40} />
                </div>
                <div className="card-body">
                  <h4 className="title text-dark">Institiution Partnership &amp; MOU</h4>
                  {/* <p className="text-muted mb-0">Planning creating Architecture of webapp/mobileapp is our first move with requirments. </p> */}
                </div>
              </div>
            </div>
            <div className="col-md-4 mt-md-5 pt-md-3 mt-4 pt-2">
              <div className="card features work-process bg-transparent process-arrow border-0 text-center">
                <div className="icons rounded h1 text-center text-indigo px-3">
                  <Code size={40} />
                </div>
                <div className="card-body">
                  <h4 className="title text-dark">One Day AI Hackathons</h4>
                  {/* <p className="text-muted mb-0">Development, Deployment are the next important steps which are done by our NODEHIVE technicians.</p> */}
                </div>
              </div>
            </div>
            <div className="col-md-4 mt-md-5 pt-md-5 mt-4 pt-2">
              <div className="card features work-process bg-transparent d-none-arrow border-0 text-center">
                <div className="icons rounded h1 text-center text-indigo px-3">
                  <Cloud size={40} />
                </div>
                <div className="card-body">
                  <h4 className="title text-dark">Certification Trainings</h4>
                  {/* <p className="text-muted mb-0">Customers feedbacks are the important part which helps to improve the applications via new update.</p> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <section class="py-4 mt-4">
        <div>
          <div className="row justify-content-center">
            <div className="col-12 text-center">
              <div className="section-title mb-2 pb-2">
                <h4 className="title mb-2">Universities</h4>
              </div>
            </div>
          </div>
          <div class="row justify-content-center align-items-center gap-6">
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/JNTU.jpg" class="avatar avatar-md-md" alt="" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/dsu.png" class="avatar avatar-md-md" alt="" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/srm.png" class="avatar avatar-md-mdx2" alt="" />
            </div>
          </div>
        </div>
      </section> */}
      {/* <section class="py-4 ">
        <div>
          <div className="row justify-content-center">
            <div className="col-12 text-center">
              <div className="section-title mb-2 pb-2">
                <h4 className="title mb-2">Engineering Institutions</h4>
              </div>
            </div>
          </div>
          <div class="row justify-content-center align-items-center gap-6">

            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/KPR.png" class="avatar avatar-md-mdx" alt="" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/Sri%20Eswar.png" class="avatar avatar-md-mdx2" alt="" />
            </div>
            <div class="text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/NIE.png" class="avatar avatar-md-md" alt="" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/SNS.png" class="avatar avatar-md-md" alt="" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/mepco.png" class="avatar avatar-md-mdx" alt="" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/image.png" class="avatar avatar-md-mdx2" alt="" />
            </div>
          </div>
        </div>
      </section> */}
      <section class="py-4 ">
        <div>
          <div className="row justify-content-center">
            <div className="col-12 text-center">
              <div className="section-title mb-2 pb-2">
                <h4 className="title mb-2">Cloud Certification Partners</h4>
              </div>
            </div>
          </div>
          <div class="row justify-content-center align-items-center gap-6">
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/gcppart.png" class="avatar avatar-md-mdx" alt="Google Cloud Partner" />
            </div>
            <div class=" text-center py-4">
              <img src="https://ik.imagekit.io/qy4xfjnfo/Atomcode%20Website%20image%20assets/College%20Logos/awspart.png" class="avatar avatar-md-mdx" alt="AWS Partner (APN)" />
            </div>
          </div>
        </div>
      </section>
      <div className="mt-1 mb-5 p-4 justify-content-center">
        <div className=" text-center">
          <div className="section-title">
            <h4 className="title mb-4">Have Question ? Get in touch!</h4>
            <p className="text-muted para-desc mx-auto">Enhance your institution’s capabilities with industry-relevant cloud and coding training from
              <span className="text-indigo font-weight-bold"> Atom Code</span>'s certified experts.
              Contact us to get more detials about our services and pricings</p>
            <Link href="/contact" className="btn btn-primary mt-4"><i className="mdi mdi-phone" /> Contact us</Link>
          </div>
        </div>
      </div>
    </>
  )
}
