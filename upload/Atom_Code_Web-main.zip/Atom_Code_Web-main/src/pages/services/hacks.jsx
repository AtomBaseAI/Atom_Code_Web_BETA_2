import Link from 'next/link'
import { Code, Smartphone, Shield, Zap, Cloud, CheckCircle, Star } from 'react-feather';

export default function Mobile() {
  return (
    <>
      <div>

        <section className="bg-half bg-light d-table w-100">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-lg-12 text-center">
                <div className="page-next-level">
                  <h4 className="title">AI Student Hackathon</h4>
                  <div className="page-next">
                    <nav aria-label="breadcrumb" className="d-inline-block">
                      <ul className="breadcrumb bg-white rounded shadow mb-0">
                        <li className="breadcrumb-item">
                          <Link href="/">Atom Code</Link>
                        </li>
                        <li className="breadcrumb-item">
                          <Link href="#">Events</Link>
                        </li>
                        <li
                          className="breadcrumb-item active"
                          aria-current="page"
                        >
                          One Day AI Hackathon
                        </li>
                      </ul>
                    </nav>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="position-relative">
          <div className="shape overflow-hidden text-white">
            <svg
              viewBox="0 0 2880 48"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z"
                fill="currentColor"
              />
            </svg>
          </div>
        </div>

        <section className="section pb-4">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 text-center">
                <div className="section-title mb-4 pb-2">
                  <h4 className="title mb-4">Hackathon Highlights</h4>
                  <p className="text-muted para-desc mx-auto mb-0">
                    Join{" "}
                    <span className="text-indigo font-weight-bold">
                      Atom Code
                    </span>{" "}
                    for an exciting one-day AI Hackathon where students
                    collaborate, build modern AI-powered applications, learn
                    from mentors, and showcase innovative solutions.
                  </p>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-lg-4 col-md-6 mt-4 pt-2">
                <div className="media key-feature align-items-center p-3 rounded shadow">
                  <div className="icon text-center rounded-circle mr-3">
                    <Code className="fea icon-ex-md text-indigo" />
                  </div>
                  <div className="media-body">
                    <h4 className="title mb-0">AI App Development</h4>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 mt-4 pt-2">
                <div className="media key-feature align-items-center p-3 rounded shadow">
                  <div className="icon text-center rounded-circle mr-3">
                    <Smartphone className="fea icon-ex-md text-indigo" />
                  </div>
                  <div className="media-body">
                    <h4 className="title mb-0">
                      Modern Web & Mobile Apps
                    </h4>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 mt-4 pt-2">
                <div className="media key-feature align-items-center p-3 rounded shadow">
                  <div className="icon text-center rounded-circle mr-3">
                    <Zap className="fea icon-ex-md text-indigo" />
                  </div>
                  <div className="media-body">
                    <h4 className="title mb-0">Build in One Day</h4>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 mt-4 pt-2">
                <div className="media key-feature align-items-center p-3 rounded shadow">
                  <div className="icon text-center rounded-circle mr-3">
                    <Shield className="fea icon-ex-md text-indigo" />
                  </div>
                  <div className="media-body">
                    <h4 className="title mb-0">Mentor Guidance</h4>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 mt-4 pt-2">
                <div className="media key-feature align-items-center p-3 rounded shadow">
                  <div className="icon text-center rounded-circle mr-3">
                    <Cloud className="fea icon-ex-md text-indigo" />
                  </div>
                  <div className="media-body">
                    <h4 className="title mb-0">
                      Cloud & AI Tools Access
                    </h4>
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 mt-4 pt-2">
                <div className="media key-feature align-items-center p-3 rounded shadow">
                  <div className="icon text-center rounded-circle mr-3">
                    <Code className="fea icon-ex-md text-indigo" />
                  </div>
                  <div className="media-body">
                    <h4 className="title mb-0">
                      Demo & Project Showcase
                    </h4>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="container mt-100 mt-60 mb-0">
            <div className="row align-items-center">
              <div className="col-lg-7 col-md-6 order-2 order-md-1 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <div className="section-title mr-lg-5">
                  <h4 className="title mb-4">
                    Build an AI-powered application in just one day
                  </h4>

                  <p className="text-muted">
                    Our Student AI Hackathon is an immersive one-day event
                    designed to help participants transform innovative ideas
                    into working AI-powered applications. Students work in
                    teams, receive guidance from experienced mentors, explore
                    modern development tools, and present their final solution
                    before a judging panel.
                  </p>

                  <ul className="list-unstyled text-muted">
                    <li className="mb-0 py-1">
                      <span className="text-indigo h5 mr-2">
                        <CheckCircle />
                      </span>
                      Team-based AI app development challenge
                    </li>

                    <li className="mb-0 py-1">
                      <span className="text-indigo h5 mr-2">
                        <CheckCircle />
                      </span>
                      Hands-on experience with Generative AI & APIs
                    </li>

                    <li className="mb-0 py-1">
                      <span className="text-indigo h5 mr-2">
                        <CheckCircle />
                      </span>
                      Mentorship throughout ideation, development and pitching
                    </li>

                    <li className="mb-0 py-1">
                      <span className="text-indigo h5 mr-2">
                        <CheckCircle />
                      </span>
                      Build, test and deploy a working prototype within the day
                    </li>

                    <li className="mb-0 py-1">
                      <span className="text-indigo h5 mr-2">
                        <CheckCircle />
                      </span>
                      Certificates, awards and networking opportunities
                    </li>
                  </ul>
                </div>
              </div>

              <div className="col-lg-5 col-md-6 order-1 order-md-2">
                <img
                  src="https://ik.imagekit.io/atominc/ATOMCODE_Web/illustratorx/app.svg"
                  alt="AI Hackathon"
                />
              </div>
            </div>
          </div>

          <div className="container mt-100 mt-60">
            <div className="row">
              <div className="col-lg-3 col-md-6 col-12 mt-4 pt-2 mt-lg-0 pt-lg-0">
                <div className="media align-items-center features">
                  <div className="icons m-0 rounded h2 text-indigo text-center px-3">
                    <Star />
                  </div>
                  <div className="content ml-3">
                    <h5 className="mb-1">
                      <Link href="#" className="text-dark">
                        Team Collaboration
                      </Link>
                    </h5>
                    <p className="text-muted mb-0">
                      Work together to solve real-world problems.
                    </p>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-12 mt-4 pt-2 mt-lg-0 pt-lg-0">
                <div className="media align-items-center features">
                  <div className="icons m-0 rounded h2 text-indigo text-center px-3">
                    <Star />
                  </div>
                  <div className="content ml-3">
                    <h5 className="mb-1">
                      <Link href="#" className="text-dark">
                        AI Technologies
                      </Link>
                    </h5>
                    <p className="text-muted mb-0">
                      LLMs, APIs, Automation & Intelligent Apps.
                    </p>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-12 mt-4 pt-2 mt-lg-0 pt-lg-0">
                <div className="media align-items-center features">
                  <div className="icons m-0 rounded h2 text-indigo text-center px-3">
                    <Star />
                  </div>
                  <div className="content ml-3">
                    <h5 className="mb-1">
                      <Link href="#" className="text-dark">
                        Live Mentoring
                      </Link>
                    </h5>
                    <p className="text-muted mb-0">
                      Industry experts support your journey.
                    </p>
                  </div>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 col-12 mt-4 pt-2 mt-lg-0 pt-lg-0">
                <div className="media align-items-center features">
                  <div className="icons m-0 rounded h2 text-indigo text-center px-3">
                    <Star />
                  </div>
                  <div className="content ml-3">
                    <h5 className="mb-1">
                      <Link href="#" className="text-dark">
                        Demo & Awards
                      </Link>
                    </h5>
                    <p className="text-muted mb-0">
                      Pitch your project and win exciting prizes.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}